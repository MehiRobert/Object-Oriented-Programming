#include "FilePhysicalCopies.h"


void FilePhysicalCopy::setFilename(std::string filename)
{
	this->Path = filename;
}
