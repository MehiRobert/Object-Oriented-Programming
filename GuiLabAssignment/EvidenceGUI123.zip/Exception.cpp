#pragma warning (disable : 4996)
#include "Exception.h"
#include <algorithm>
using namespace std;
