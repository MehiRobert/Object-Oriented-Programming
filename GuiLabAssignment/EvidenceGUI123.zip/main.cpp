#include "EvidenceGUI.h"
#include <QtWidgets/QApplication>
#include "FileRepository.h"
#include "Validate.h"
#include "Service.h"
#include "EvidenceGUI.h";
#include "myListGUI.h"

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	FileRepo repo{};
	repo.set_file("Lab9.txt");
	ValidateInput input{};
	PhysicalCopies repo2{};
	Service service{ repo , repo2 };
	EvidenceGUI gui{ service,repo2 };
	gui.show();
	return a.exec();
}
